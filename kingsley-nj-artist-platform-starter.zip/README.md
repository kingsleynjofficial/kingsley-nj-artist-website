# Kingsley NJ — Artist Platform starter

A Next.js + Supabase starter for the official Kingsley NJ website and SEINT MUSIC admin system.

## Included in this first build

- Public artist homepage with Kingsley NJ / NJ / The Bar / The Seint identity.
- SEINT MUSIC label branding.
- Public music catalogue that displays streaming-platform buttons only; it does not upload or host audio.
- Private admin sign-in using Supabase Auth.
- Admin editing for social/streaming profile URLs.
- Admin release editor with editable songwriter, composer and producer credits.
- Per-release streaming links, story/description, artwork URL, behind-the-scenes video URL and promo clip URL.
- Database schema prepared for products, orders, events, ticket types, fan profiles and moderated comments.
- Responsive dark visual design.

## Requirements

- Node.js 20+
- A Supabase project
- A hosting account (for example Vercel) when ready to publish

## Run locally

1. Install dependencies:
   `npm install`
2. Copy `.env.example` to `.env.local`.
3. Add your Supabase project URL and anon/public key.
4. In Supabase SQL Editor, run `supabase/schema.sql`.
5. Create your admin user in Supabase Authentication.
6. Copy that user's UUID and run the final `insert into public.admin_users...` statement in the SQL file.
7. Start the app:
   `npm run dev`
8. Open `http://localhost:3000`. Admin dashboard: `http://localhost:3000/admin`.

## Important security notes

- Only use the Supabase anon/public key in `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
- Never put a Supabase service-role key in browser code or a `NEXT_PUBLIC_` variable.
- Do not enter social media or streaming account passwords. The dashboard stores public profile/release URLs only.
- Enable email confirmation and strong admin passwords in Supabase Auth.
- Review RLS policies before launch and test with a non-admin account.

## Not yet live / requires next implementation phase

This is a real starter codebase, not a deployed production service. The following need implementation and configuration before customers can transact:
- Paystack/Flutterwave payment initialization and server-side webhook verification.
- Product creation/editing, cart, checkout, order fulfilment and shipping.
- Event/ticket purchasing, QR ticket issuance/validation, refunds and safe resale.
- Fan registration, newsletter delivery, comments UI and moderation workflow.
- Analytics instrumentation and revenue reports.
- File storage for artwork and video clips (audio uploads are intentionally excluded).
- Domain, hosting, backups, monitoring, privacy policy and terms.

No real payment credentials or platform passwords are included.
