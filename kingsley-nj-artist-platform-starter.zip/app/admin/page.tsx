"use client";
import { FormEvent, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type Release = { id:string; title:string; release_type:string; description:string|null; artwork_url:string|null; release_date:string|null; songwriter_credits:string[]|null; composer_credits:string[]|null; producer_credits:string[]|null; spotify_url:string|null; apple_music_url:string|null; amazon_music_url:string|null; youtube_music_url:string|null; audiomack_url:string|null; behind_the_scenes_url:string|null; promo_clip_url:string|null; published:boolean; };
const socialPlatforms = ["Instagram","TikTok","X","YouTube","Facebook","Snapchat","Threads","Kick"];
const streamPlatforms = ["Spotify","Apple Music","Amazon Music","YouTube Music","Audiomack","Deezer","SoundCloud"];
export default function Admin() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [session,setSession]=useState<any>(null); const [message,setMessage]=useState("");
  const [socials,setSocials]=useState<Record<string,string>>({});
  const [release,setRelease]=useState<Partial<Release>>({title:"",release_type:"Single",songwriter_credits:["Kingsley Njoku"],composer_credits:["Kingsley Njoku"],producer_credits:["Kingsley Njoku"],published:false});
  const [releases,setReleases]=useState<Release[]>([]);
  const [active,setActive]=useState("overview");
  const [extraLinks,setExtraLinks]=useState<Record<string,string>>({});
  useEffect(()=>{ if(!supabase)return; supabase.auth.getSession().then(({data})=>setSession(data.session)); const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s)); return ()=>subscription.unsubscribe(); },[]);
  useEffect(()=>{ if(session) loadData(); },[session]);
  async function loadData(){
    if(!supabase)return;
    const [s,r]=await Promise.all([supabase.from("social_profiles").select("*"),supabase.from("releases").select("*").order("created_at",{ascending:false})]);
    const map:Record<string,string>={}; (s.data||[]).forEach((x:any)=>map[x.platform]=x.profile_url); setSocials(map); setReleases((r.data||[]) as Release[]);
  }
  async function signIn(e:FormEvent){e.preventDefault(); if(!supabase){setMessage("Add your Supabase project URL and anon key to .env.local first.");return;} const {error}=await supabase.auth.signInWithPassword({email,password}); setMessage(error?.message||"");}
  async function saveSocials(){if(!supabase)return; const rows=Object.entries(socials).filter(([,v])=>v.trim()).map(([platform,profile_url])=>({platform,profile_url,is_visible:true})); const {error}=await supabase.from("social_profiles").upsert(rows,{onConflict:"platform"}); setMessage(error?.message||"Social profile URLs saved.");}
  async function saveRelease(e:FormEvent){e.preventDefault();if(!supabase)return;
    const payload:any={...release,other_links:extraLinks,published:!!release.published};
    delete payload.id;
    const {error}=release.id ? await supabase.from("releases").update(payload).eq("id",release.id) : await supabase.from("releases").insert(payload);
    setMessage(error?.message||"Release saved."); if(!error){setRelease({title:"",release_type:"Single",songwriter_credits:["Kingsley Njoku"],composer_credits:["Kingsley Njoku"],producer_credits:["Kingsley Njoku"],published:false});setExtraLinks({});loadData();}
  }
  async function logout(){await supabase?.auth.signOut();setSession(null);}
  if(!session) return <div className="admin-shell"><div className="wrap" style={{maxWidth:460}}><a className="brand" href="/">KINGSLEY NJ / SEINT MUSIC</a><div className="card" style={{marginTop:30}}><div className="eyebrow">Private access</div><h2 style={{margin:"10px 0 20px"}}>Artist administration</h2><form className="form" onSubmit={signIn}><label>Admin email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/></label><button>Sign in</button></form>{message&&<p className="muted">{message}</p>}<p className="muted" style={{fontSize:12}}>Admin accounts are created securely in your Supabase project. Do not share your admin password.</p></div></div></div>;
  return <div className="admin-shell"><div className="wrap">
    <div className="row"><div><div className="eyebrow">SEINT MUSIC · CONTROL ROOM</div><h1 style={{fontSize:38,marginTop:8}}>Artist dashboard</h1></div><button className="secondary" onClick={logout}>Sign out</button></div>
    <div className="stats"><div className="card stat"><span className="muted">Published releases</span><strong>{releases.filter(r=>r.published).length}</strong></div><div className="card stat"><span className="muted">Total releases</span><strong>{releases.length}</strong></div><div className="card stat"><span className="muted">Social profiles</span><strong>{Object.values(socials).filter(Boolean).length}</strong></div><div className="card stat"><span className="muted">Store & tickets</span><strong>Setup next</strong></div></div>
    <div className="admin-grid"><aside className="sidebar card"><a href="#overview" onClick={()=>setActive("overview")}>Overview</a><a href="#platforms" onClick={()=>setActive("platforms")}>Platform connections</a><a href="#releases" onClick={()=>setActive("releases")}>Music & releases</a><a href="#store" onClick={()=>setActive("store")}>Merchandise & orders</a><a href="#events" onClick={()=>setActive("events")}>Shows & tickets</a><a href="#fans" onClick={()=>setActive("fans")}>Fans & community</a><a href="#analytics" onClick={()=>setActive("analytics")}>Analytics</a></aside>
    <div className="stack">
      {message&&<div className="notice">{message}</div>}
      <div className="card" id="overview"><h2>Welcome, Kingsley.</h2><p className="muted">Manage your artist website, SEINT MUSIC releases and audience from one place.</p><div className="notice">This starter dashboard currently includes secure sign-in, editable social profile URLs and release management. Store checkout, ticket payments, fan accounts and live analytics require their payment and service integrations before launch.</div></div>
      <div className="card" id="platforms"><h2>Platform connections</h2><p className="muted">Paste public profile URLs. Never enter social or streaming account passwords here.</p><div className="grid" style={{gridTemplateColumns:"repeat(2,minmax(0,1fr))",marginTop:18}}>{[...socialPlatforms,...streamPlatforms].map(p=><label key={p}>{p}<input value={socials[p]||""} placeholder={`https://${p.toLowerCase().replaceAll(" ","")}.com/...`} onChange={e=>setSocials({...socials,[p]:e.target.value})}/></label>)}</div><div style={{marginTop:18}}><button onClick={saveSocials}>Save platform URLs</button></div></div>
      <div className="card" id="releases"><div className="row"><h2>Music & releases</h2><button className="secondary" onClick={()=>{setRelease({title:"",release_type:"Single",songwriter_credits:["Kingsley Njoku"],composer_credits:["Kingsley Njoku"],producer_credits:["Kingsley Njoku"],published:false});setExtraLinks({});}}>New release</button></div>
        <form className="form" onSubmit={saveRelease} style={{marginTop:18}}>
          <label>Song / project title<input value={release.title||""} onChange={e=>setRelease({...release,title:e.target.value})} required/></label>
          <label>Release type<select value={release.release_type||"Single"} onChange={e=>setRelease({...release,release_type:e.target.value})}><option>Single</option><option>EP</option><option>Album</option><option>Mixtape</option></select></label>
          <label>Release date<input type="date" value={release.release_date||""} onChange={e=>setRelease({...release,release_date:e.target.value})}/></label>
          <label>Artwork image URL<input value={release.artwork_url||""} onChange={e=>setRelease({...release,artwork_url:e.target.value})} placeholder="Paste hosted artwork URL"/></label>
          <label>Song description / story / inspiration<textarea value={release.description||""} onChange={e=>setRelease({...release,description:e.target.value})}/></label>
          <label>Songwriter credits (separate names with commas)<input value={(release.songwriter_credits||[]).join(", ")} onChange={e=>setRelease({...release,songwriter_credits:e.target.value.split(",").map(x=>x.trim()).filter(Boolean)})}/></label>
          <label>Composer credits<input value={(release.composer_credits||[]).join(", ")} onChange={e=>setRelease({...release,composer_credits:e.target.value.split(",").map(x=>x.trim()).filter(Boolean)})}/></label>
          <label>Producer credits<input value={(release.producer_credits||[]).join(", ")} onChange={e=>setRelease({...release,producer_credits:e.target.value.split(",").map(x=>x.trim()).filter(Boolean)})}/></label>
          <div className="grid" style={{gridTemplateColumns:"repeat(2,minmax(0,1fr))"}}>{["spotify_url","apple_music_url","amazon_music_url","youtube_music_url","audiomack_url"].map(k=><label key={k}>{k.replaceAll("_"," ")}<input value={(release as any)[k]||""} onChange={e=>setRelease({...release,[k]:e.target.value})} placeholder="Paste release URL"/></label>)}</div>
          <label>Behind-the-scenes video URL<input value={release.behind_the_scenes_url||""} onChange={e=>setRelease({...release,behind_the_scenes_url:e.target.value})}/></label>
          <label>Short promotional clip URL<input value={release.promo_clip_url||""} onChange={e=>setRelease({...release,promo_clip_url:e.target.value})}/></label>
          <label>Other platform links (one per line: Platform name,URL)<textarea value={Object.entries(extraLinks).map(([k,v])=>`${k},${v}`).join("\n")} onChange={e=>{const m:Record<string,string>={};e.target.value.split("\n").forEach(line=>{const i=line.indexOf(",");if(i>0)m[line.slice(0,i).trim()]=line.slice(i+1).trim();});setExtraLinks(m);}} placeholder={"Deezer,https://...\nSoundCloud,https://..."}/></label>
          <label><span><input type="checkbox" checked={!!release.published} onChange={e=>setRelease({...release,published:e.target.checked})} style={{width:"auto",marginRight:8}}/>Publish this release on the public website</span></label>
          <button type="submit">Save release</button>
        </form>
        <div style={{marginTop:26}}><h3>Existing releases</h3>{releases.length===0?<p className="muted">No releases yet.</p>:releases.map(r=><div className="row" key={r.id} style={{borderTop:"1px solid var(--line)",padding:"12px 0"}}><div><strong>{r.title}</strong><div className="muted" style={{fontSize:12}}>{r.release_type} · {r.published?"Published":"Draft"}</div></div><button className="secondary" onClick={()=>{setRelease(r);setExtraLinks({});window.location.hash="releases";}}>Edit</button></div>)}</div>
      </div>
      <div className="card" id="store"><h2>Merchandise & orders</h2><p className="muted">Product catalogue, stock, customer orders, fulfilment, discounts and revenue reporting are planned modules. Payment provider and shipping configuration are required before accepting orders.</p></div>
      <div className="card" id="events"><h2>Shows & tickets</h2><p className="muted">Event creation, ticket tiers, QR validation, refunds and eligible fan-to-fan resale will be added with ticketing/payment integration.</p></div>
      <div className="card" id="fans"><h2>Fans & community</h2><p className="muted">Fan registrations, newsletter consent, comments, memberships and moderation controls are planned modules.</p></div>
      <div className="card" id="analytics"><h2>Analytics</h2><p className="muted">Sales, audience and conversion analytics will populate after the store, ticketing and analytics events are connected.</p></div>
    </div></div>
  </div></div>;
}
