import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Kingsley NJ | Official Website",
  description: "Official home of Kingsley NJ — music, stories, shows and SEINT MUSIC."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
