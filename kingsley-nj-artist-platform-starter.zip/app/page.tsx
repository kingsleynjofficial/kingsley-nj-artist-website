"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type Release = { id:string; title:string; release_type:string; description:string|null; artwork_url:string|null; release_date:string|null; spotify_url:string|null; apple_music_url:string|null; amazon_music_url:string|null; youtube_music_url:string|null; audiomack_url:string|null; other_links:Record<string,string>|null; };
type Social = { platform:string; profile_url:string; };
const defaultPlatforms = ["Spotify","Apple Music","Amazon Music","YouTube Music","Audiomack","Deezer","SoundCloud"];
const defaultSocials = ["Instagram","TikTok","X","YouTube","Facebook","Snapchat","Threads","Kick"];
function urlFor(r:Release, p:string) {
  const map:Record<string,string|null> = {"Spotify":r.spotify_url,"Apple Music":r.apple_music_url,"Amazon Music":r.amazon_music_url,"YouTube Music":r.youtube_music_url,"Audiomack":r.audiomack_url};
  return map[p] || r.other_links?.[p] || null;
}
export default function Home() {
  const [releases,setReleases] = useState<Release[]>([]);
  const [socials,setSocials] = useState<Social[]>([]);
  const [loading,setLoading] = useState(true);
  useEffect(() => {
    async function load() {
      if (!supabase) { setLoading(false); return; }
      const [r,s] = await Promise.all([
        supabase.from("releases").select("*").eq("published",true).order("release_date",{ascending:false}),
        supabase.from("social_profiles").select("platform,profile_url").eq("is_visible",true)
      ]);
      if (r.data) setReleases(r.data as Release[]);
      if (s.data) setSocials(s.data as Social[]);
      setLoading(false);
    }
    load();
  },[]);
  return <>
    <header className="site-header"><div className="wrap nav">
      <a className="brand" href="#">KINGSLEY NJ</a>
      <nav className="navlinks"><a href="#music">Music</a><a href="#story">The Story</a><a href="#shows">Shows</a><a href="#store">Store</a><a href="#connect">Connect</a></nav>
      <a className="button secondary" href="/admin">Artist login</a>
    </div></header>
    <main>
      <div className="hero"><div className="wrap">
        <div className="eyebrow">Independent artist · SEINT MUSIC</div>
        <h1>KINGSLEY<br/>NJ.</h1>
        <p>Music, stories and experiences. Welcome to the official home of Kingsley NJ — also known as NJ, The Bar and The Seint.</p>
        <div className="actions"><a className="button" href="#music">Explore the music</a><a className="button secondary" href="#connect">Follow the journey</a></div>
      </div></div>
      <section id="music"><div className="wrap">
        <div className="section-head"><div><div className="eyebrow">The catalogue</div><h2>Music</h2></div><span className="muted">Listen on your platform of choice</span></div>
        {loading ? <p className="muted">Loading releases…</p> : releases.length === 0 ? <div className="card"><h3>New music is on the way.</h3><p className="muted">Official releases and streaming buttons will appear here when published from the artist dashboard.</p></div> :
          <div className="grid">{releases.map(r=><article className="card" key={r.id}>
            <div className="artwork" style={r.artwork_url?{backgroundImage:`linear-gradient(0deg,#0009,transparent),url("${r.artwork_url}")`,backgroundSize:"cover",backgroundPosition:"center"}:{}}>{r.release_type.toUpperCase()}</div>
            <h3>{r.title}</h3><p className="muted">{r.release_date || "Release date to be announced"}</p>
            {r.description && <p className="muted">{r.description}</p>}
            <div className="platforms">{defaultPlatforms.map(p=>{const u=urlFor(r,p);return u?<a className="pill" key={p} href={u} target="_blank" rel="noreferrer">{p} ↗</a>:null})}</div>
            {r.other_links && <div className="platforms">{Object.entries(r.other_links).filter(([k,v])=>v && !defaultPlatforms.includes(k)).map(([k,v])=><a className="pill" key={k} href={v} target="_blank" rel="noreferrer">{k} ↗</a>)}</div>}
          </article>)}</div>}
      </div></section>
      <section id="story"><div className="wrap"><div className="eyebrow">More than the music</div><h2>Behind the music.</h2><p className="muted" style={{maxWidth:680,lineHeight:1.8}}>Every song has a story. Explore the inspiration, experiences, writing process, production notes and behind-the-scenes moments behind each release. Song stories and short-form clips will be published here.</p></div></section>
      <section id="shows"><div className="wrap"><div className="eyebrow">Live experiences</div><h2>Shows & tickets.</h2><p className="muted">Upcoming performances, event details and ticket purchasing will be listed here as events are added by the artist team.</p></div></section>
      <section id="store"><div className="wrap"><div className="eyebrow">Official goods</div><h2>Merchandise.</h2><p className="muted">Official SEINT MUSIC and Kingsley NJ merchandise, physical music and limited releases. The store will open when products and payment processing are configured.</p></div></section>
      <section id="connect"><div className="wrap"><div className="eyebrow">Stay connected</div><h2>Follow the journey.</h2><p className="muted">Find Kingsley NJ across social platforms.</p><div className="socials">{socials.length ? socials.map(s=><a className="pill" key={s.platform} href={s.profile_url} target="_blank" rel="noreferrer">{s.platform} ↗</a>) : defaultSocials.map(s=><span className="pill" key={s}>{s} · add profile in admin</span>)}</div></div></section>
    </main>
    <footer><div className="wrap row"><span>© {new Date().getFullYear()} KINGSLEY NJ</span><span>SEINT MUSIC · Independent by design</span></div></footer>
  </>;
}
