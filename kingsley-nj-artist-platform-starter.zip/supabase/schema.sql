-- Run this file in Supabase SQL Editor.
-- Create an admin user in Supabase Authentication first, then insert their UUID below.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.admin_users where user_id = auth.uid()); $$;

create table if not exists public.social_profiles (
  id uuid primary key default gen_random_uuid(),
  platform text not null unique,
  profile_url text not null,
  is_visible boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.releases (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  release_type text not null default 'Single',
  description text,
  artwork_url text,
  release_date date,
  songwriter_credits text[] default array['Kingsley Njoku']::text[],
  composer_credits text[] default array['Kingsley Njoku']::text[],
  producer_credits text[] default array['Kingsley Njoku']::text[],
  featured_artists text[] default '{}',
  lyrics text,
  creation_story text,
  spotify_url text,
  apple_music_url text,
  amazon_music_url text,
  youtube_music_url text,
  audiomack_url text,
  other_links jsonb not null default '{}'::jsonb,
  behind_the_scenes_url text,
  promo_clip_url text,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  category text,
  price_minor bigint not null default 0,
  currency text not null default 'NGN',
  stock_quantity integer not null default 0,
  image_url text,
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_email text not null,
  status text not null default 'pending',
  currency text not null default 'NGN',
  total_minor bigint not null default 0,
  payment_provider text,
  provider_reference text,
  shipping_details jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price_minor bigint not null
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  venue text,
  city text,
  country text,
  starts_at timestamptz,
  description text,
  ticket_url text,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.ticket_types (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  name text not null,
  price_minor bigint not null,
  currency text not null default 'NGN',
  quantity_available integer not null default 0,
  sale_enabled boolean not null default false
);

create table if not exists public.fan_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  newsletter_opt_in boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.fan_comments (
  id uuid primary key default gen_random_uuid(),
  release_id uuid not null references public.releases(id) on delete cascade,
  fan_id uuid references public.fan_profiles(id) on delete set null,
  body text not null,
  is_approved boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.social_profiles enable row level security;
alter table public.releases enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.events enable row level security;
alter table public.ticket_types enable row level security;
alter table public.fan_profiles enable row level security;
alter table public.fan_comments enable row level security;

create policy "Admins manage admin list" on public.admin_users for all using (public.is_admin()) with check (public.is_admin());
create policy "Public reads visible socials" on public.social_profiles for select using (is_visible = true);
create policy "Admins manage socials" on public.social_profiles for all using (public.is_admin()) with check (public.is_admin());
create policy "Public reads published releases" on public.releases for select using (published = true);
create policy "Admins manage releases" on public.releases for all using (public.is_admin()) with check (public.is_admin());
create policy "Public reads active products" on public.products for select using (is_active = true);
create policy "Admins manage products" on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy "Admins manage orders" on public.orders for all using (public.is_admin()) with check (public.is_admin());
create policy "Admins manage order items" on public.order_items for all using (public.is_admin()) with check (public.is_admin());
create policy "Public reads published events" on public.events for select using (is_published = true);
create policy "Admins manage events" on public.events for all using (public.is_admin()) with check (public.is_admin());
create policy "Public reads sale ticket types" on public.ticket_types for select using (sale_enabled = true);
create policy "Admins manage ticket types" on public.ticket_types for all using (public.is_admin()) with check (public.is_admin());
create policy "Fans read own profile" on public.fan_profiles for select using (id = auth.uid() or public.is_admin());
create policy "Fans update own profile" on public.fan_profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "Admins manage fan profiles" on public.fan_profiles for all using (public.is_admin()) with check (public.is_admin());
create policy "Public reads approved comments" on public.fan_comments for select using (is_approved = true);
create policy "Fans create comments" on public.fan_comments for insert with check (fan_id = auth.uid());
create policy "Admins moderate comments" on public.fan_comments for all using (public.is_admin()) with check (public.is_admin());

-- After creating the admin user in Supabase Auth, run:
-- insert into public.admin_users (user_id) values ('PASTE-AUTH-USER-UUID-HERE');
